'use strict';

function collectSameElements(collectionA, objectB) {
  return '实现练习要求，并改写该行代码。';
}
